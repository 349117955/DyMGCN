import torch
from DyMGCN.gcn import GCN_Layer, sym_norm_adj
from DyMGCN.utils import GatedFeatureFusion
from DyMGCN.cross_graphs import CrossGraphs
import math
Tensor = torch.Tensor

import os
os.environ['CUDA_VISIBLE_DEVICES'] = '1'


class GRUCell(torch.nn.Module):
    def __init__(self, hidden_size, input_size, station_num):
        super(GRUCell, self).__init__()

        self.device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
        self.hidden_size = hidden_size
        self.input_size = input_size
        self.station_num = station_num

        self.gcn_layer1_s = GCN_Layer(self.input_size, self.hidden_size)
        self.gcn_layer2_s = GCN_Layer(self.input_size, self.hidden_size)

        self.gcn_layer1_f = GCN_Layer(self.input_size, self.hidden_size)
        self.gcn_layer2_f = GCN_Layer(self.input_size, self.hidden_size)

        self.gcn_layer1_t = GCN_Layer(self.input_size, self.hidden_size)
        self.gcn_layer2_t = GCN_Layer(self.input_size, self.hidden_size)

        self.gcn_layer1_a = GCN_Layer(self.input_size, self.hidden_size)
        self.gcn_layer2_a = GCN_Layer(self.input_size, self.hidden_size)

        self.cGraph_s = CrossGraphs(self.station_num, self.hidden_size, num_rules=1)
        self.cGraph_f = CrossGraphs(self.station_num, self.hidden_size, num_rules=1)
        self.cGraph_t = CrossGraphs(self.station_num, self.hidden_size, num_rules=1)
        self.cGraph_a = CrossGraphs(self.station_num, self.hidden_size, num_rules=1)

        self.gff_s = GatedFeatureFusion(self.hidden_size, self.hidden_size)
        self.gff_f = GatedFeatureFusion(self.hidden_size, self.hidden_size)
        self.gff_t = GatedFeatureFusion(self.hidden_size, self.hidden_size)
        self.gff_a = GatedFeatureFusion(self.hidden_size, self.hidden_size)

        self.Wr_s = torch.nn.Linear(self.hidden_size + self.hidden_size, self.hidden_size, bias=False)
        self.Wz_s = torch.nn.Linear(self.hidden_size + self.hidden_size, self.hidden_size, bias=False)
        self.Wh_s = torch.nn.Linear(self.hidden_size + self.hidden_size, self.hidden_size, bias=False)

        self.Wr_f = torch.nn.Linear(self.hidden_size + self.hidden_size, self.hidden_size, bias=False)
        self.Wz_f = torch.nn.Linear(self.hidden_size + self.hidden_size, self.hidden_size, bias=False)
        self.Wh_f = torch.nn.Linear(self.hidden_size + self.hidden_size, self.hidden_size, bias=False)

        self.Wr_t = torch.nn.Linear(self.hidden_size + self.hidden_size, self.hidden_size, bias=False)
        self.Wz_t = torch.nn.Linear(self.hidden_size + self.hidden_size, self.hidden_size, bias=False)
        self.Wh_t = torch.nn.Linear(self.hidden_size + self.hidden_size, self.hidden_size, bias=False)

        self.Wr_a = torch.nn.Linear(self.hidden_size + self.hidden_size, self.hidden_size, bias=False)
        self.Wz_a = torch.nn.Linear(self.hidden_size + self.hidden_size, self.hidden_size, bias=False)
        self.Wh_a = torch.nn.Linear(self.hidden_size + self.hidden_size, self.hidden_size, bias=False)

        self.reset_parameters()


    def reset_parameters(self):
        for weight in self.parameters():
            stdv = 1. / math.sqrt(weight.size(0))
            torch.nn.init.uniform_(weight, -stdv, stdv)


    def forward(self, x1, x2, x3, x4, adj_s, adj_f, adj_t, adj_a, hidden_s, hidden_f, hidden_t, hidden_a):
        # nor adj
        adj_s = sym_norm_adj(adj_s)
        adj_f = sym_norm_adj(adj_f)
        adj_t = sym_norm_adj(adj_t)
        adj_a = sym_norm_adj(adj_a)

        # s Layers
        x_Gconv1_s = self.gcn_layer1_s(x1, adj_s.to(self.device))
        x_Gconv2_s = self.gcn_layer2_s(x1, adj_s.to(self.device) ** 2)

        # f Layers
        x_Gconv1_f = self.gcn_layer1_f(x2, adj_f.to(self.device))
        x_Gconv2_f = self.gcn_layer2_f(x2, adj_f.to(self.device) ** 2)

        # t Layers
        x_Gconv1_t = self.gcn_layer1_t(x3, adj_t.to(self.device))
        x_Gconv2_t = self.gcn_layer2_t(x3, adj_t.to(self.device) ** 2)

        # a Layers
        x_Gconv1_a = self.gcn_layer1_a(x4, adj_a.to(self.device))
        x_Gconv2_a = self.gcn_layer2_a(x4, adj_a.to(self.device) ** 2)

        # cross to s
        featrue_s = self.cGraph_s(x_Gconv2_s, x_Gconv1_f, x_Gconv1_t, x_Gconv1_a)
        x_Gconv2_s_ = self.gff_s(x_Gconv2_s, featrue_s)

        # cross to f
        featrue_f = self.cGraph_f(x_Gconv2_f, x_Gconv1_s, x_Gconv1_t, x_Gconv1_a)
        x_Gconv2_f_ = self.gff_f(x_Gconv2_f, featrue_f)

        # cross to t
        featrue_t = self.cGraph_t(x_Gconv2_t, x_Gconv1_s, x_Gconv1_f, x_Gconv1_a)
        x_Gconv2_t_ = self.gff_t(x_Gconv2_t, featrue_t)

        # cross to a
        featrue_a = self.cGraph_a(x_Gconv2_a, x_Gconv1_s, x_Gconv1_f, x_Gconv1_t)
        x_Gconv2_a_ = self.gff_a(x_Gconv2_a, featrue_a)

        x_Gconv_s = x_Gconv1_s + x_Gconv2_s_
        x_Gconv_f = x_Gconv1_f + x_Gconv2_f_
        x_Gconv_t = x_Gconv1_t + x_Gconv2_t_
        x_Gconv_a = x_Gconv1_a + x_Gconv2_a_

        # GRUs
        x_out_s = torch.cat([x_Gconv_s, hidden_s.to(self.device)], dim=2)
        r_out_s = torch.sigmoid(self.Wr_s(x_out_s))
        z_out_s = torch.sigmoid(self.Wz_s(x_out_s))
        x2_out_s = torch.cat([r_out_s * hidden_s.to(self.device), x_Gconv_s], dim=2)
        h_out_s = torch.tanh(self.Wh_s(x2_out_s))
        h_out_s = (1 - z_out_s) * hidden_s.to(self.device) + z_out_s * h_out_s

        x_out_f = torch.cat([x_Gconv_f, hidden_f.to(self.device)], dim=2)
        r_out_f = torch.sigmoid(self.Wr_f(x_out_f))
        z_out_f = torch.sigmoid(self.Wz_f(x_out_f))
        x2_out_f = torch.cat([r_out_f * hidden_f.to(self.device), x_Gconv_f], dim=2)
        h_out_f = torch.tanh(self.Wh_f(x2_out_f))
        h_out_f = (1 - z_out_f) * hidden_f.to(self.device) + z_out_f * h_out_f

        x_out_t = torch.cat([x_Gconv_t, hidden_t.to(self.device)], dim=2)
        r_out_t = torch.sigmoid(self.Wr_t(x_out_t))
        z_out_t = torch.sigmoid(self.Wz_t(x_out_t))
        x2_out_t = torch.cat([r_out_t * hidden_t.to(self.device), x_Gconv_t], dim=2)
        h_out_t = torch.tanh(self.Wh_t(x2_out_t))
        h_out_t = (1 - z_out_t) * hidden_t.to(self.device) + z_out_t * h_out_t

        x_out_a = torch.cat([x_Gconv_a, hidden_a.to(self.device)], dim=2)
        r_out_a = torch.sigmoid(self.Wr_a(x_out_a))
        z_out_a = torch.sigmoid(self.Wz_a(x_out_a))
        x2_out_a = torch.cat([r_out_a * hidden_a.to(self.device), x_Gconv_a], dim=2)
        h_out_a = torch.tanh(self.Wh_t(x2_out_a))
        h_out_a = (1 - z_out_a) * hidden_a.to(self.device) + z_out_a * h_out_a

        del adj_s, adj_f, adj_t, adj_a, x_Gconv1_s, x_Gconv2_s, x_Gconv2_s_, featrue_s, x_Gconv_s, x_Gconv1_f, x_Gconv2_f, x_Gconv2_f_, featrue_f, x_Gconv_f, \
            x_Gconv1_t, x_Gconv2_t, x_Gconv2_t_, featrue_t, x_Gconv_t, x_Gconv1_a, x_Gconv2_a, x_Gconv2_a_, featrue_a, x_Gconv_a, x_out_s, r_out_s, z_out_s, x2_out_s, \
            x_out_f, r_out_f, z_out_f, x2_out_f, x_out_t, r_out_t, z_out_t, x2_out_t, x_out_a, r_out_a, z_out_a, x2_out_a

        return h_out_s, h_out_f, h_out_t, h_out_a