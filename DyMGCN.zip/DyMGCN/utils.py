import torch
import torch.nn.functional as F
Tensor = torch.Tensor

import os
os.environ['CUDA_VISIBLE_DEVICES'] = '1'




class GatedFeatureFusion(torch.nn.Module):
    def __init__(self, input_size, output_size):
        super(GatedFeatureFusion, self).__init__()
        self.fc1 = torch.nn.Linear(input_size, output_size)
        self.fc2 = torch.nn.Linear(input_size, output_size)
        self.gate = torch.nn.Sigmoid()

    def forward(self, x1, x2):
        # Apply linear transformations
        f1 = self.fc1(x1)
        f2 = self.fc2(x2)

        # Compute the gate value
        gate_value = self.gate(f1 + f2)

        # Fuse the features
        fused_features = gate_value * f1 + (1 - gate_value) * f2

        del f1, f2, gate_value

        return fused_features



class Attention(torch.nn.Module):
    def __init__(self, in_size, hidden_size):
        super(Attention, self).__init__()

        self.project = torch.nn.Sequential(
            torch.nn.Linear(in_size, hidden_size),
            torch.nn.Tanh(),
            torch.nn.Linear(hidden_size, 1, bias=False)
        )

    def forward(self, z):
        w = self.project(z)
        beta = torch.nn.functional.softmax(w, dim=1)

        return (beta * z).sum(1), beta

