import torch
import os
import math
Tensor = torch.Tensor

os.environ['CUDA_VISIBLE_DEVICES'] = '1'



class GaussianMembershipFunction(torch.nn.Module):
    def __init__(self, in_features, out_features):
        super(GaussianMembershipFunction, self).__init__()
        self.centers = torch.nn.Parameter(torch.randn(out_features, in_features))
        self.sigmas = torch.nn.Parameter(torch.randn(out_features, in_features))
        self.reset_parameters()

    def reset_parameters(self):
        for weight in self.parameters():
            stdv = 1. / math.sqrt(weight.size(0))
            torch.nn.init.uniform_(weight, -stdv, stdv)


    def forward(self, x):
        num = (x.unsqueeze(2) - self.centers) ** 2
        denom = 2 * (self.sigmas ** 2)
        gauss = torch.exp(-num / denom)
        del num, denom
        return gauss



class FuzzyRuleLayer(torch.nn.Module):
    def __init__(self, input_dim, num_rules):
        super(FuzzyRuleLayer, self).__init__()
        self.fuzzify = GaussianMembershipFunction(input_dim, num_rules)


    def forward(self, x):
        x = self.fuzzify(x)
        weights = torch.nn.functional.softmax(x, dim=2)
        return torch.sum(weights * x, dim=2)



class CrossGraphs(torch.nn.Module):
    def __init__(self, station_num, station_dim, num_rules, dropout=0.3):
        super(CrossGraphs, self).__init__()

        self.device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
        self.station_num = station_num
        self.station_dim = station_dim
        self.fnn2 = FuzzyRuleLayer(station_dim, num_rules)
        # self.fnn3 = FuzzyRuleLayer(station_dim, num_rules)
        # self.fnn4 = FuzzyRuleLayer(station_dim, num_rules)
        self.linear2 = torch.nn.Linear(station_dim, station_dim).to(self.device)
        # self.linear3 = torch.nn.Linear(station_dim, station_dim).to(self.device)
        # self.linear4 = torch.nn.Linear(station_dim, station_dim).to(self.device)
        self.concat_linear = torch.nn.Linear(station_dim * 3, station_dim).to(self.device)
        self.dropout2 = torch.nn.Dropout(dropout)
        self.dropout3 = torch.nn.Dropout(dropout)
        self.dropout4 = torch.nn.Dropout(dropout)

        self.reset_parameters()

    def reset_parameters(self):
        for weight in self.parameters():
            stdv = 1. / math.sqrt(weight.size(0))
            torch.nn.init.uniform_(weight, -stdv, stdv)


    def forward(self, x1, x2, x3, x4):
        # FNN feature
        fnn_input_x2 = self.linear2(self.fnn2(x1))
        # fnn_input_x3 = self.linear3(self.fnn3(x1))
        # fnn_input_x4 = self.linear4(self.fnn4(x1))

        fnn_input_x2_reshape = fnn_input_x2.permute(0, 2, 1)
        # fnn_input_x3_reshape = fnn_input_x3.permute(0, 2, 1)
        # fnn_input_x4_reshape = fnn_input_x4.permute(0, 2, 1)
        x2 = self.dropout2(x2)
        x3 = self.dropout3(x3)
        x4 = self.dropout4(x4)
        weight_x2 = torch.nn.functional.softmax(torch.matmul(x2, fnn_input_x2_reshape), dim=1)
        weight_x3 = torch.nn.functional.softmax(torch.matmul(x3, fnn_input_x2_reshape), dim=1)
        # weight_x3 = torch.nn.functional.softmax(torch.matmul(x3, fnn_input_x3_reshape), dim=1)
        weight_x4 = torch.nn.functional.softmax(torch.matmul(x4, fnn_input_x2_reshape), dim=1)
        # weight_x4 = torch.nn.functional.softmax(torch.matmul(x4, fnn_input_x4_reshape), dim=1)

        output_x2 = torch.matmul(weight_x2, x2)
        output_x3 = torch.matmul(weight_x3, x3)
        output_x4 = torch.matmul(weight_x4, x4)

        output = self.concat_linear(torch.cat([output_x2, output_x3, output_x4], dim=-1))

        # del fnn_input_x2, fnn_input_x3, fnn_input_x4, fnn_input_x2_reshape, fnn_input_x3_reshape, fnn_input_x4_reshape, weight_x2, weight_x3, weight_x4, output_x2, output_x3, output_x4
        del fnn_input_x2,  fnn_input_x2_reshape, weight_x2, weight_x3, weight_x4, output_x2, output_x3, output_x4

        return output