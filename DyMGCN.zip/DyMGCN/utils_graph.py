import torch
import numpy as np
from math import radians, cos, sin, asin
from math import sqrt
import pandas as pd
from scipy.optimize import curve_fit
import os


os.environ['KMP_DUPLICATE_LIB_OK'] = 'True'


# 关系图构建
def RGC():
    def calDistance(lat1, lng1, lat2, lng2):
        lng1, lat1, lng2, lat2 = map(radians, [float(lng1), float(lat1), float(lng2), float(lat2)])  # 经纬度转换成弧度
        dlon = lng2 - lng1
        dlat = lat2 - lat1
        a = sin(dlat / 2) ** 2 + cos(lat1) * cos(lat2) * sin(dlon / 2) ** 2
        distances = 2 * asin(sqrt(a)) * 6371 * 1000  # 地球平均半径，6371km
        distance = round(distances / 1000, 3)
        return distance

    def SPAdj():
        # ----------------Spatial adjacency-------------
        sigma = 7.2944
        dist_adj = []
        for line in open("station_loc.txt", encoding='utf-8'):  # 设置文件对象并读取每一行文件
            array = line.split(',')
            station_lng = array[2]
            station_lat = array[1]
            dist_ = []
            for line in open("station_loc.txt", encoding='utf-8'):  # 设置文件对象并读取每一行文件
                array = line.split(',')
                station_lng1 = array[2]
                station_lat1 = array[1]
                dist = calDistance(station_lat1, station_lng1, station_lat, station_lng)
                if dist > 10:
                    dist = 0
                else:
                    dist = np.exp(-(dist ** 2) / sigma ** 2)
                dist_.append(dist)
            dist_adj.append(dist_)
        kernel = torch.FloatTensor(dist_adj)
        # 去掉自环，并且转换0,1矩阵
        kernel = torch.where(kernel != 0, torch.tensor(1), torch.tensor(0)).fill_diagonal_(0)
        return kernel.float()

    def FCAdj():
        poi = pd.read_csv('london_station.csv')
        station_array = ['BL0', 'CD1', 'CD9', 'GN0', 'GN3', 'GR4', 'GR9', 'HV1', 'KF1', 'LW2', 'MY7', 'ST5', 'TH4']
        func_adj = []
        sim = []
        pois = []
        for station in station_array:
            #         st_poi=poi['name'].values.tolist()
            st_poi = poi[poi['name'].isin([station])].values.tolist()[0][1:6]
            eu_dist = []
            for station1 in station_array:
                st_poi1 = poi[poi['name'].isin([station1])].values.tolist()[0][1:6]
                eu_dist_sum = 0
                for i in range(len(st_poi)):
                    euclidean_distance = (st_poi[i] - st_poi1[i]) ** 2
                    eu_dist_sum += euclidean_distance
                if eu_dist_sum == 0:
                    eu_dist_sum = 1
                eu_dist_sum = 1 / eu_dist_sum
                if eu_dist_sum < 5e-05:
                    eu_dist_sum = 0
                eu_dist.append(eu_dist_sum)
                sim.append(eu_dist_sum)
            func_adj.append(eu_dist)
        func_kernel = torch.FloatTensor(func_adj)
        # 去掉自环，并且转换0,1矩阵
        func_kernel = torch.where(func_kernel != 0, torch.tensor(1), torch.tensor(0)).fill_diagonal_(0)
        return func_kernel.float()

    def multipl(a, b):
        sumofab = 0.0
        for i in range(len(a)):
            temp = a[i] * b[i]
            sumofab += temp
        return sumofab

    def corrcoef(x, y):
        n = len(x)
        # 求和
        sum1 = sum(x)
        sum2 = sum(y)
        # 求乘积之和
        sumofxy = multipl(x, y)
        # 求平方和
        sumofx2 = sum([pow(i, 2) for i in x])
        sumofy2 = sum([pow(j, 2) for j in y])
        num = sumofxy - (float(sum1) * float(sum2) / n)
        # 计算皮尔逊相关系数
        den = sqrt((sumofx2 - float(sum1 ** 2) / n) * (sumofy2 - float(sum2 ** 2) / n))
        if den == 0:
            return 0
        return num / den

    def PTAdj():
        average = pd.read_csv("month_average_pm25.csv")
        station_array = ['BL0', 'CD1', 'CD9', 'GN0', 'GN3', 'GR4', 'GR9', 'HV1', 'KF1', 'LW2', 'MY7', 'ST5', 'TH4']
        pattern_adj = []
        sim = []
        for station in station_array:
            pattern_pear = []
            for station1 in station_array:
                values = average[station].values.tolist()
                values1 = average[station1].values.tolist()
                pearson = corrcoef(values, values1)
                if pearson < 0.93:
                    pearson = 0
                pattern_pear.append(pearson)
            pattern_adj.append(pattern_pear)
        func_kernel = torch.FloatTensor(pattern_adj)
        # 去掉自环，并且转换0,1矩阵
        func_kernel = torch.where(func_kernel != 0., torch.tensor(1), torch.tensor(0)).fill_diagonal_(0)
        return func_kernel.float()

    def norm_distance(input):
        distances_matrix = torch.cdist(input, input, p=2)
        # normalize_0 to 1.
        min_val = torch.min(distances_matrix)
        max_val = torch.max(distances_matrix)
        normalized_distance = (distances_matrix - min_val) / (max_val - min_val)
        return normalized_distance

    def calculate_semivariance(points):
        N = points.shape[0]
        semivariances = torch.zeros(N, N)
        for i in range(N):
            for j in range(N):
                semivariances[i, j] = 0.5 * torch.mean((points[i] - points[j]) ** 2)
        return semivariances

    def gaussian(h, r, s, n=0):
        return n + s * (1. - np.exp(- (h ** 2 / (r / 2.) ** 2)))

    def get_fit_bounds(x, y):
        n = np.nanmin(y)
        r = np.nanmax(x)
        s = np.nanmax(y)
        return 0, [r, s, n]

    def get_fit_func(x, y, model):
        try:
            bounds = get_fit_bounds(x, y)
            popt, _ = curve_fit(model, x, y, method='trf', p0=bounds[1], bounds=bounds)
            return popt
        except Exception as e:
            return [0, 0, 0]

    def gen_semivariogram(distances, variances, bins):
        valid_variances, valid_bins = [], []
        for b in range(len(bins) - 1):
            left, right = bins[b], bins[b + 1]
            mask = (distances >= left) & (distances < right)
            if np.count_nonzero(mask) > 10:
                v = np.nanmean(variances[mask])
                d = np.nanmean(distances[mask])
                valid_variances.append(v)
                valid_bins.append(d)
        x, y = np.array(valid_bins), np.array(valid_variances)
        popt = get_fit_func(x, y, model=gaussian)
        return popt

    def gaussian_fit(r, s, n, distans_mx):
        return n + s * (1. - np.exp(- (distans_mx ** 2 / (r / 2.) ** 2)))

    def AGAdj():
        threshold = 1.5065e+00
        average = pd.read_csv("ave_data.csv")
        station_array = ['BL0', 'CD1', 'CD9', 'GN0', 'GN3', 'GR4', 'GR9', 'HV1', 'KF1', 'LW2', 'MY7', 'ST5', 'TH4']
        stations = len(station_array)
        values = torch.tensor(average[station_array].values, dtype=torch.float)
        values = values.contiguous().view(stations, 1)

        bins = torch.arange(0, 1.1, 0.1)
        dis_mx = norm_distance(values)
        semivar = calculate_semivariance(values)
        popt = gen_semivariogram(dis_mx, semivar, bins)
        r, s, n = torch.tensor(popt)
        AG_mx = gaussian_fit(r, s, n, dis_mx)
        # print(SC_mx)
        AG_adj = (AG_mx < threshold).int()
        # 去掉自环，并且转换0,1矩阵
        AG_adj = torch.where(AG_adj != 0., torch.tensor(1), torch.tensor(0)).fill_diagonal_(0)

        return AG_adj.float()


    As = SPAdj()
    Af = FCAdj()
    At = PTAdj()
    Aa = AGAdj()
    return As, Af, At, Aa





