import torch
import math
from DyMGCN.gru_cell import GRUCell
from DyMGCN.utils import Attention
import random



class Encoder_Decoder(torch.nn.Module):
    def __init__(self):
        super(Encoder_Decoder, self).__init__()
        self.device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
        self.hidden_size = 64
        self.forecast = 6
        self.stations = 13
        self.input_size = 24
        self.Wt = torch.nn.Parameter(torch.FloatTensor(self.hidden_size, self.hidden_size))
        self.Wt_ = torch.nn.Parameter(torch.FloatTensor(self.hidden_size, self.hidden_size))
        self.bt = torch.nn.Parameter(torch.FloatTensor(self.hidden_size))
        self.vt = torch.nn.Parameter(torch.FloatTensor(self.hidden_size))
        self.ws = torch.nn.Parameter(torch.FloatTensor(self.hidden_size))
        self.wf = torch.nn.Parameter(torch.FloatTensor(self.hidden_size))
        self.wt = torch.nn.Parameter(torch.FloatTensor(self.hidden_size))
        self.wa = torch.nn.Parameter(torch.FloatTensor(self.hidden_size))
        self.bfc = torch.nn.Parameter(torch.FloatTensor(self.stations))
        self.att = Attention(self.hidden_size, 32)
        self.cell1 = GRUCell(self.hidden_size, self.input_size, self.stations)
        self.cell2 = GRUCell(self.hidden_size, self.hidden_size, self.stations)
        self.dcell = GRUCell(self.hidden_size, self.hidden_size, self.stations)
        self.reset_parameters()


    def reset_parameters(self):
        for weight in self.parameters():
            stdv = 1. / math.sqrt(weight.size(0))
            torch.nn.init.uniform_(weight, -stdv, stdv)


    def input_transform(self, x):
        local_inputs, labels = x
        #  16, 12, 34, 26      16, 6, 1, 26
        local_inputs = local_inputs.permute(1, 0, 2, 3)  # (12h, batch, feature, stations)
        labels = labels.permute(1, 0, 2, 3)  # (6h, batch, 1features, stations)
        n_input_encoder = local_inputs.data.size(2)  # 28features
        batch_size = local_inputs.data.size(1)
        _local_inputs = local_inputs.contiguous().view(-1, n_input_encoder, self.stations)
        _local_inputs = torch.split(_local_inputs, batch_size, 0)
        encoder_inputs = _local_inputs
        _labels = labels.contiguous().view(-1, self.stations)
        _labels = torch.split(_labels, batch_size, 0)  # （batch, 1, stations）
        _lastinp = local_inputs[11:12, :, 0:1, :]  # 1, 256, 1, 35
        _lastinp = _lastinp.contiguous().view(-1, 1, self.stations)
        _lastinp = torch.split(_lastinp, batch_size, 0)
        decoder_inputs = list(_lastinp) + list(_labels[:-1])  # 6*(256, 1, 35)

        del local_inputs, labels, n_input_encoder, batch_size, _local_inputs, _lastinp

        return encoder_inputs, _labels, decoder_inputs


    def Encoder(self, encoder_inputs, As, Af, At, Aa):
        Inputs = encoder_inputs  # 12 (batch, feature, stations)
        batch_size = Inputs[0].data.size(0)
        stations = Inputs[0].data.size(2)
        lasth_hidden_As = torch.rand(batch_size, stations, self.hidden_size)
        lasth_hidden_Af = torch.rand(batch_size, stations, self.hidden_size)
        lasth_hidden_At = torch.rand(batch_size, stations, self.hidden_size)
        lasth_hidden_Aa = torch.rand(batch_size, stations, self.hidden_size)
        hlist_As = []
        hlist_Af = []
        hlist_At = []
        hlist_Aa = []

        for flinput in Inputs:
            flinputx = flinput.permute(0, 2, 1)  # stations, feature,
            flinputx = torch.as_tensor(flinputx, dtype=torch.float32).to(self.device)

            h1_As, h1_Af, h1_At, h1_Aa = self.cell1(flinputx, flinputx, flinputx, flinputx, As, Af, At, Aa, lasth_hidden_As, lasth_hidden_Af, lasth_hidden_At, lasth_hidden_Aa)
            h2_As, h2_Af, h2_At, h2_Aa = self.cell2(h1_As, h1_Af, h1_At, h1_Aa, As, Af, At, Aa, lasth_hidden_As, lasth_hidden_Af, lasth_hidden_At, lasth_hidden_Aa)
            lasth_hidden_As = h2_As
            lasth_hidden_Af = h2_Af
            lasth_hidden_At = h2_At
            lasth_hidden_Aa = h2_Aa
            hlist_As.append(h2_As)
            hlist_Af.append(h2_Af)
            hlist_At.append(h2_At)
            hlist_Aa.append(h2_Aa)


        del Inputs, batch_size, stations, lasth_hidden_As, lasth_hidden_Af, lasth_hidden_At, lasth_hidden_Aa

        return hlist_As, hlist_Af, hlist_At, hlist_Aa



    def Decoder(self, As, Af, At, Aa, decoder_inputs, encoder_inputs, hlist_As, hlist_Af, hlist_At, hlist_Aa, teather_ratio):
        Inputs = encoder_inputs
        batch_size = Inputs[0].data.size(0)
        stations = Inputs[0].data.size(2)
        lasthd_As = torch.rand(batch_size, stations, self.hidden_size)
        lasthd_Af = torch.rand(batch_size, stations, self.hidden_size)
        lasthd_At = torch.rand(batch_size, stations, self.hidden_size)
        lasthd_Aa = torch.rand(batch_size, stations, self.hidden_size)
        predicts = []

        for dint in decoder_inputs:
            etlist = []
            for h_As, h_Af, h_At, h_Aa in zip(hlist_As, hlist_Af, hlist_At, hlist_Aa):
                # et = torch.stack([h_As, h_Af, h_At, h_com_sf, h_com_st, h_com_ft, h_com_sft], dim=1)
                et = torch.stack([h_As, h_Af, h_At, h_Aa], dim=1)
                et, _ = self.att(et)
                etlist.append(et)

            sumalfa1 = torch.zeros(batch_size, stations, self.hidden_size).to(self.device)
            alfalist1 = []
            for et in etlist:
                alfa = torch.matmul(torch.tanh(
                    torch.matmul(et.to(self.device), self.Wt) + torch.matmul(lasthd_As.to(self.device),
                                                                                 self.Wt_) + self.bt), self.vt)
                alfa = alfa.reshape(batch_size, -1, 1)
                alfalist1.append(torch.exp(alfa))
                sumalfa1 = sumalfa1 + torch.exp(alfa)
            C1 = torch.zeros(batch_size, stations, self.hidden_size).to(self.device)
            for et, alfa in zip(etlist, alfalist1):
                alfa = torch.div(alfa, sumalfa1)
                C1 = C1 + alfa * et

            sumalfa2 = torch.zeros(batch_size, stations, self.hidden_size).to(self.device)
            alfalist2 = []
            for et in etlist:
                alfa = torch.matmul(torch.tanh(
                    torch.matmul(et.to(self.device), self.Wt) + torch.matmul(lasthd_Af.to(self.device),
                                                                             self.Wt_) + self.bt), self.vt)
                alfa = alfa.reshape(batch_size, -1, 1)
                alfalist2.append(torch.exp(alfa))
                sumalfa2 = sumalfa2 + torch.exp(alfa)
            C2 = torch.zeros(batch_size, stations, self.hidden_size).to(self.device)
            for et, alfa in zip(etlist, alfalist2):
                alfa = torch.div(alfa, sumalfa2)
                C2 = C2 + alfa * et

            sumalfa3 = torch.zeros(batch_size, stations, self.hidden_size).to(self.device)
            alfalist3 = []
            for et in etlist:
                alfa = torch.matmul(torch.tanh(
                    torch.matmul(et.to(self.device), self.Wt) + torch.matmul(lasthd_At.to(self.device),
                                                                             self.Wt_) + self.bt), self.vt)
                alfa = alfa.reshape(batch_size, -1, 1)
                alfalist3.append(torch.exp(alfa))
                sumalfa3 = sumalfa3 + torch.exp(alfa)
            C3 = torch.zeros(batch_size, stations, self.hidden_size).to(self.device)
            for et, alfa in zip(etlist, alfalist3):
                alfa = torch.div(alfa, sumalfa3)
                C3 = C3 + alfa * et

            sumalfa4 = torch.zeros(batch_size, stations, self.hidden_size).to(self.device)
            alfalist4 = []
            for et in etlist:
                alfa = torch.matmul(torch.tanh(
                    torch.matmul(et.to(self.device), self.Wt) + torch.matmul(lasthd_Aa.to(self.device),
                                                                             self.Wt_) + self.bt), self.vt)
                alfa = alfa.reshape(batch_size, -1, 1)
                alfalist4.append(torch.exp(alfa))
                sumalfa4 = sumalfa4 + torch.exp(alfa)
            C4 = torch.zeros(batch_size, stations, self.hidden_size).to(self.device)
            for et, alfa in zip(etlist, alfalist4):
                alfa = torch.div(alfa, sumalfa4)
                C4 = C4 + alfa * et


            ran_t = random.random()
            is_teather = ran_t < teather_ratio
            dint = dint.reshape(batch_size, self.stations, 1).float().repeat(1, 1, self.hidden_size)
            C1 = (dint if is_teather else C1)
            C2 = (dint if is_teather else C2)
            C3 = (dint if is_teather else C3)
            C4 = (dint if is_teather else C4)


            d_As, d_Af, d_At, d_Aa = self.dcell(C1, C2, C3, C4, As, Af, At, Aa, lasthd_As, lasthd_Af, lasthd_At, lasthd_Aa)
            lasthd_As = d_As
            lasthd_Af = d_Af
            lasthd_At = d_At
            lasthd_Aa = d_Aa
            ypredict = torch.tanh(torch.matmul(d_As, self.ws) + torch.matmul(d_Af, self.wf) + torch.matmul(d_At, self.wt) + torch.matmul(d_Aa, self.wa))
            predicts.append(ypredict)

        del lasthd_As, lasthd_Af, lasthd_At, lasthd_Aa

        return predicts


    def forward(self, x, As, Af, At, Aa, teather_ratio):
        encoder_inputs, labels, decoder_inputs = self.input_transform(x)
        hlist_As, hlist_Af, hlist_At, hlist_Aa = self.Encoder(encoder_inputs, As, Af, At, Aa)
        predicts = self.Decoder(As, Af, At, Aa, decoder_inputs, encoder_inputs, hlist_As, hlist_Af, hlist_At, hlist_Aa, teather_ratio)

        del encoder_inputs, decoder_inputs, hlist_As, hlist_Af, hlist_At, hlist_Aa

        return predicts, labels

